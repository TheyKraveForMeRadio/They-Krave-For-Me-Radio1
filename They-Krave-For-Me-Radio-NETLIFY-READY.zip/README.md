They Krave For Me Radio — Next.js (App Router) + Tailwind — GitHub-ready
